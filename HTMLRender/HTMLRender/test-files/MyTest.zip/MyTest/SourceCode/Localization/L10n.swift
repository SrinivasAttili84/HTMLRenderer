//
//  L10n.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 11/08/26.
//

import SwiftUI

enum L10n {

    static let home = LocalizedStringKey("home")

    static let manuals = LocalizedStringKey("manuals")

    static let search = LocalizedStringKey("search")

    static let settings = LocalizedStringKey("settings")

    static let syncNow = LocalizedStringKey("sync_now")
}
