//
//  AppRouter.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 10/08/26.
//

import SwiftUI

enum AppRoute: Hashable {
    case manualViewer(manualCode: String)
    case recentElementDetails(elementId: String)
}

@MainActor
final class AppRouter: ObservableObject {
    @Published var path = NavigationPath()

    func navigate(to route: AppRoute) {
        path.append(route)
    }

    func popToRoot() {
        path.removeLast(path.count)
    }
}
