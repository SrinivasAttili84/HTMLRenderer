//
//  AppContainer.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 10/08/26.
//

import SwiftUI

@MainActor
final class AppContainer: ObservableObject {
    var router: AppRouter
    private let homeRepository: HomeRepositoryProtocol

    init() {
        self.router = AppRouter()
        self.homeRepository = MockHomeRepository()
    }

    func makeHomeViewModel() -> HomeViewModel {
        HomeViewModel(
            repository: homeRepository,
            router: router
        )
    }
}
