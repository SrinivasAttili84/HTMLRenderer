//
//  Routes.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 10/08/26.
//

import Foundation


enum Route: Hashable {

    case viewer
    case details(
        manualId: String,
        sectionId: String
    )
    
    // future

    case htmlViewer(nodeId: String)

    case figureViewer(figureId: String)

    case popup(id: String)

    case searchResult(id: String)

    case settings
}
