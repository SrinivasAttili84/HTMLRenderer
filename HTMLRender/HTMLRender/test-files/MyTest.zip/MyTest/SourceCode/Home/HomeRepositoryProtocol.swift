//
//  HomeRepositoryProtocol.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import Foundation

protocol HomeRepositoryProtocol {
    func loadDashboard() async throws -> HomeDashboardState
}
