//
//  SyncStatusPanelView.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

struct SyncStatusPanelView: View {
    let statuses: [SyncStatus]
    let lastSyncedText: String
    let onSyncTap: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: AppSpacing.md) {
            Text("DATA SYNCHRONISATION")
                .font(AppTypography.sectionTitle)
                .foregroundStyle(AppColors.textPrimary)

            VStack(spacing: AppSpacing.md) {
                ForEach(Array(statuses.enumerated()), id: \.offset) { _, status in
                    VStack(alignment: .leading, spacing: AppSpacing.sm) {
                        Text(status.title)
                            .font(AppTypography.body)
                            .foregroundStyle(AppColors.textPrimary)

                        RingProgressView(
                            progress: status.percentage,
                            colour: colour(for: status.colourType),
                            centreTitle: "\(Int(status.percentage * 100))%",
                            centreSubtitle: status.availableText
                        )
                        .frame(width: 210, height: 210)
                        .frame(maxWidth: .infinity)
                    }
                    .padding(AppSpacing.md)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay {
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(AppColors.border, lineWidth: 1)
                    }
                }
            }

            Spacer(minLength: AppSpacing.md)

            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Last Synced:")
                        .font(AppTypography.body)
                        .foregroundStyle(AppColors.textSecondary)

                    Text(lastSyncedText)
                        .font(AppTypography.body)
                        .foregroundStyle(AppColors.textSecondary)
                }

                Spacer()

                Button(action: onSyncTap) {
                    Text("Sync Data Now")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 190, height: 48)
                        .background(AppColors.airbusBlue)
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                }
                .buttonStyle(.plain)
            }
            .padding(.top, AppSpacing.sm)
        }
        .padding(AppSpacing.md)
        .frame(minHeight: 620, alignment: .top)
        .background(AppColors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay {
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppColors.border, lineWidth: 1)
        }
    }

    private func colour(for type: SyncColourType) -> Color {
        switch type {
        case .blue:
            return AppColors.airbusActionBlue
        case .green:
            return AppColors.green
        }
    }
}
