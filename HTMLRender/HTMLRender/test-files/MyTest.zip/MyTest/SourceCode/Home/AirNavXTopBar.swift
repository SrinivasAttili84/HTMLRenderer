//
//  AirNavXTopBar.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

struct AirNavXTopBar: View {
    let ttlText: String
    let aircraftText: String

    var body: some View {
        HStack(spacing: AppSpacing.md) {
            Button(action: {}) {
                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 25, weight: .medium))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
            }

            Divider()
                .frame(height: 32)
                .background(Color.white.opacity(0.55))

            Text("AIRBUS")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(.white)

            Divider()
                .frame(height: 32)
                .background(Color.white.opacity(0.55))

            HStack(spacing: 8) {
                Text("airnavX")
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(.white)

                Text("Offline")
                    .font(.system(size: 14, weight: .bold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.white.opacity(0.90))
                    .foregroundStyle(AppColors.airbusBlue)
                    .clipShape(Capsule())
            }

            Spacer()

            HStack(spacing: 10) {
                Text(ttlText)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(AppColors.gold)

                Image(systemName: "info.circle")
                    .foregroundStyle(AppColors.gold)
            }
            .padding(.horizontal, 16)
            .frame(height: 46)
            .overlay {
                RoundedRectangle(cornerRadius: 8)
                    .stroke(AppColors.gold, lineWidth: 1.5)
            }

            HStack(spacing: 12) {
                Text(aircraftText)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(AppColors.airbusActionBlue)

                Image(systemName: "pencil")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(AppColors.airbusActionBlue)
            }
            .padding(.horizontal, 16)
            .frame(height: 46)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
        .padding(.horizontal, 28)
        .background(AppColors.airbusBlue)
    }
}
