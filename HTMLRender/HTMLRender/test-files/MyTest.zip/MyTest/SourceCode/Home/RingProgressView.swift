//
//  RingProgressView.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

struct RingProgressView: View {
    let progress: Double
    let colour: Color
    let centreTitle: String
    let centreSubtitle: String

    var body: some View {
        ZStack {
            Circle()
                .stroke(
                    Color.gray.opacity(0.18),
                    style: StrokeStyle(lineWidth: 24, lineCap: .butt)
                )

            Circle()
                .trim(from: 0, to: max(0, min(progress, 1)))
                .stroke(
                    colour,
                    style: StrokeStyle(lineWidth: 24, lineCap: .butt)
                )
                .rotationEffect(.degrees(-90))

            VStack(spacing: 4) {
                Text(centreTitle)
                    .font(.system(size: 32, weight: .regular))
                    .foregroundStyle(AppColors.textPrimary)

                Text(centreSubtitle)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(AppColors.textPrimary)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(8)
    }
}
