//
//  HomeViewModel.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

@MainActor
protocol HomeViewModelProtocol: ObservableObject {
    var manuals: [ManualItem] { get }
    var recentElements: [RecentElement] { get }
    var syncStatuses: [SyncStatus] { get }
    var lastSyncedText: String { get }
    var ttlText: String { get }
    var aircraftText: String { get }
    var searchText: String { get set }

    func onAppear()
    func openManual(_ manual: ManualItem)
    func openRecentElement(_ element: RecentElement)
    func syncData()
}

@MainActor
final class HomeViewModel: HomeViewModelProtocol {
    @Published private(set) var manuals: [ManualItem] = []
    @Published private(set) var recentElements: [RecentElement] = []
    @Published private(set) var syncStatuses: [SyncStatus] = []
    @Published private(set) var lastSyncedText: String = ""
    @Published private(set) var ttlText: String = ""
    @Published private(set) var aircraftText: String = ""

    @Published var searchText: String = ""

    private let repository: HomeRepositoryProtocol
    private let router: AppRouter

    init(
        repository: HomeRepositoryProtocol,
        router: AppRouter
    ) {
        self.repository = repository
        self.router = router
    }

    func onAppear() {
        Task {
            do {
                let state = try await repository.loadDashboard()
                manuals = state.manuals
                recentElements = state.recentElements
                syncStatuses = state.syncStatuses
                lastSyncedText = state.lastSyncedText
                ttlText = state.ttlText
                aircraftText = state.aircraftText
            } catch {
                manuals = []
                recentElements = []
                syncStatuses = []
            }
        }
    }

    func openManual(_ manual: ManualItem) {
        router.navigate(to: .manualViewer(manualCode: manual.code))
    }

    func openRecentElement(_ element: RecentElement) {
        router.navigate(to: .recentElementDetails(elementId: element.id))
    }

    func syncData() {
        // Later connect with Offline backend sync use case.
    }
}
