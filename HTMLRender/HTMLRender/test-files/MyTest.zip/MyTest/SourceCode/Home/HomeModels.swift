//
//  HomeModels.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import Foundation

struct ManualItem: Identifiable, Hashable {
    let id: String
    let code: String
    let title: String
    let revision: String
    let subtitle: String?
}

struct RecentElement: Identifiable, Hashable {
    let id: String
    let manualCode: String
    let referenceNumber: String
    let title: String
    let applicability: String
    let revision: String
}

struct SyncStatus: Hashable {
    let title: String
    let percentage: Double
    let availableText: String
    let colourType: SyncColourType
}

enum SyncColourType {
    case blue
    case green
}

struct HomeDashboardState {
    let manuals: [ManualItem]
    let recentElements: [RecentElement]
    let syncStatuses: [SyncStatus]
    let lastSyncedText: String
    let ttlText: String
    let aircraftText: String
}
