//
//  MockHomeRepository.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import Foundation

struct MockHomeRepository: HomeRepositoryProtocol {
    func loadDashboard() async throws -> HomeDashboardState {
        HomeDashboardState(
            manuals: [
                ManualItem(
                    id: "amm",
                    code: "AMM",
                    title: "Aircraft Maintenance Manual",
                    revision: "Rev: 20-July-2026",
                    subtitle: nil
                ),
                ManualItem(
                    id: "tsm",
                    code: "TSM",
                    title: "Troubleshooting Manual",
                    revision: "Rev: 20-July-2026",
                    subtitle: nil
                ),
                ManualItem(
                    id: "ipc",
                    code: "IPC",
                    title: "Illustrated Parts Catalog",
                    revision: "Rev: 20-July-2026",
                    subtitle: nil
                ),
                ManualItem(
                    id: "srm",
                    code: "SRM",
                    title: "Structural Repair Manual",
                    revision: "Rev: 20-July-2026",
                    subtitle: nil
                ),
                ManualItem(
                    id: "others",
                    code: "Others",
                    title: "MP, MIPD, AFI",
                    revision: "Select Manuals",
                    subtitle: nil
                )
            ],
            recentElements: [
                RecentElement(
                    id: "1",
                    manualCode: "AMM",
                    referenceNumber: "32-42-27-000-001-A",
                    title: "Removal of the Main Wheel Brake",
                    applicability: "** ON A/C FSN ALL - A330-BGA",
                    revision: "Rev: 87 (20-July-2026)"
                ),
                RecentElement(
                    id: "2",
                    manualCode: "AMM",
                    referenceNumber: "32-42-27-000-001-A",
                    title: "Installation of the Brake",
                    applicability: "** ON A/C FSN ALL - A330-BGA",
                    revision: "Rev: 87 (20-July-2026)"
                ),
                RecentElement(
                    id: "3",
                    manualCode: "TSM",
                    referenceNumber: "32-42-27-000-001-A",
                    title: "Loss of the BSCU Channel 1 or 2 at Electrical Transient",
                    applicability: "** ON A/C FSN ALL - A330-BGA",
                    revision: "Rev: 87 (20-July-2026)"
                ),
                RecentElement(
                    id: "4",
                    manualCode: "TSM",
                    referenceNumber: "32-42-27-000-001-A",
                    title: "Removal of the Braking/Steering Control unit (BSCU)",
                    applicability: "** ON A/C FSN ALL - A330-BGA",
                    revision: "Rev: 87 (20-July-2026)"
                ),
                RecentElement(
                    id: "5",
                    manualCode: "AMM",
                    referenceNumber: "32-42-27-000-001-A",
                    title: "Installation of the Brake",
                    applicability: "** ON A/C FSN ALL - A330-BGA",
                    revision: "Rev: 87 (20-July-2026)"
                )
            ],
            syncStatuses: [
                SyncStatus(
                    title: "Manuals",
                    percentage: 1.0,
                    availableText: "available:\n50/50",
                    colourType: .blue
                ),
                SyncStatus(
                    title: "Attachments",
                    percentage: 0.80,
                    availableText: "available:\n90/105",
                    colourType: .green
                )
            ],
            lastSyncedText: "10 July 2026 | 08:59",
            ttlText: "TTL - 2 days 14hrs",
            aircraftText: "BGA - A330 - F-GXLI"
        )
    }
}
