//
//  HomeView.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

struct HomeView<ViewModel: HomeViewModelProtocol>: View {
    @StateObject private var viewModel: ViewModel

    init(viewModel: ViewModel) {
        _viewModel = StateObject(wrappedValue: viewModel)
    }

    var body: some View {
        GeometryReader { proxy in
            let layout = HomeLayoutMetrics(size: proxy.size)

            VStack(spacing: 0) {
                AirNavXTopBar(
                    ttlText: viewModel.ttlText,
                    aircraftText: viewModel.aircraftText
                )
                .frame(height: 72)

                ScrollView {
                    VStack(alignment: .leading, spacing: AppSpacing.md) {
                        manualsSection(layout: layout)

                        HStack(alignment: .top, spacing: AppSpacing.md) {
                            recentElementsSection(layout: layout)
                                .frame(maxWidth: layout.leftContentWidth)

                            SyncStatusPanelView(
                                statuses: viewModel.syncStatuses,
                                lastSyncedText: viewModel.lastSyncedText,
                                onSyncTap: viewModel.syncData
                            )
                            .frame(width: layout.syncPanelWidth)
                        }
                    }
                    .padding(.horizontal, layout.horizontalPadding)
                    .padding(.top, AppSpacing.lg)
                    .padding(.bottom, AppSpacing.lg)
                }
                .background(AppColors.pageBackground)
            }
            .background(AppColors.pageBackground)
        }
        .navigationBarHidden(true)
        .task {
            viewModel.onAppear()
        }
    }

    private func manualsSection(layout: HomeLayoutMetrics) -> some View {
        VStack(alignment: .leading, spacing: AppSpacing.md) {
            Text("AVAILABLE MANUALS")
                .font(AppTypography.sectionTitle)
                .foregroundStyle(AppColors.textPrimary)

            LazyVGrid(
                columns: layout.manualGridColumns,
                spacing: AppSpacing.md
            ) {
                ForEach(viewModel.manuals) { manual in
                    ManualCardView(manual: manual) {
                        viewModel.openManual(manual)
                    }
                    .frame(height: 125)
                }
            }
        }
    }

    private func recentElementsSection(layout: HomeLayoutMetrics) -> some View {
        VStack(alignment: .leading, spacing: AppSpacing.md) {
            HStack {
                Text("RECENT ELEMENTS")
                    .font(AppTypography.sectionTitle)
                    .foregroundStyle(AppColors.textPrimary)

                Spacer()

                SearchBarView(text: $viewModel.searchText)
                    .frame(width: layout.searchWidth)
            }

            VStack(spacing: AppSpacing.sm) {
                ForEach(filteredRecentElements) { element in
                    RecentElementRowView(element: element) {
                        viewModel.openRecentElement(element)
                    }
                }
            }
        }
        .padding(AppSpacing.md)
        .background(AppColors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay {
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppColors.border, lineWidth: 1)
        }
    }

    private var filteredRecentElements: [RecentElement] {
        guard !viewModel.searchText.isEmpty else {
            return viewModel.recentElements
        }

        return viewModel.recentElements.filter {
            $0.title.localizedCaseInsensitiveContains(viewModel.searchText) ||
            $0.manualCode.localizedCaseInsensitiveContains(viewModel.searchText) ||
            $0.referenceNumber.localizedCaseInsensitiveContains(viewModel.searchText)
        }
    }
}
