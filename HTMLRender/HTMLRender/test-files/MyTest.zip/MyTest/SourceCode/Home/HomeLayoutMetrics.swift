//
//  HomeLayoutMetrics.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

struct HomeLayoutMetrics {
    let size: CGSize

    var horizontalPadding: CGFloat {
        size.width >= 1200 ? 36 : 24
    }

    var syncPanelWidth: CGFloat {
        size.width >= 1200 ? 390 : 340
    }

    var leftContentWidth: CGFloat {
        max(size.width - syncPanelWidth - horizontalPadding * 2 - AppSpacing.md, 600)
    }

    var searchWidth: CGFloat {
        size.width >= 1200 ? 420 : 330
    }

    var manualGridColumns: [GridItem] {
        let count = size.width >= 1180 ? 5 : 4

        return Array(
            repeating: GridItem(.flexible(), spacing: AppSpacing.md),
            count: count
        )
    }
}
