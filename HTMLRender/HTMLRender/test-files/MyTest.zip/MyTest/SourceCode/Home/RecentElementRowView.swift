//
//  RecentElementRowView.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 12/08/26.
//

import SwiftUI

struct RecentElementRowView: View {
    let element: RecentElement
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(alignment: .center, spacing: AppSpacing.md) {
                Text(element.manualCode)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 74, height: 42)
                    .background(AppColors.airbusActionBlue)
                    .clipShape(RoundedRectangle(cornerRadius: 6))

                VStack(alignment: .leading, spacing: 5) {
                    Text(element.referenceNumber)
                        .font(AppTypography.bodyBold)
                        .foregroundStyle(AppColors.textPrimary)

                    Text(element.title)
                        .font(AppTypography.bodyBold)
                        .foregroundStyle(AppColors.textPrimary)
                        .lineLimit(1)

                    Text(element.applicability)
                        .font(AppTypography.body)
                        .foregroundStyle(AppColors.textSecondary)
                }

                Spacer()

                Text(element.revision)
                    .font(AppTypography.body)
                    .foregroundStyle(AppColors.textSecondary)
                    .frame(width: 180, alignment: .trailing)
            }
            .padding(.horizontal, AppSpacing.md)
            .padding(.vertical, AppSpacing.md)
            .background(AppColors.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay {
                RoundedRectangle(cornerRadius: 8)
                    .stroke(AppColors.border, lineWidth: 1)
            }
        }
        .buttonStyle(.plain)
    }
}
