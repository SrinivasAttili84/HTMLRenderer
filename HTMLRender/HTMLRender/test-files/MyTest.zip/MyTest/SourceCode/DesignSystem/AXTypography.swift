//
//  AXTypography.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 11/08/26.
//

import SwiftUI

enum AXTypography {

    static let largeTitle = Font.system(
        size: 34,
        weight: .bold
    )

    static let title1 = Font.system(
        size: 28,
        weight: .semibold
    )

    static let title2 = Font.system(
        size: 22,
        weight: .semibold
    )

    static let body = Font.system(
        size: 16
    )

    static let caption = Font.system(
        size: 13
    )
}

enum AppTypography {
    static let header = Font.system(size: 26, weight: .bold)
    static let sectionTitle = Font.system(size: 18, weight: .bold)
    static let cardTitle = Font.system(size: 18, weight: .bold)
    static let body = Font.system(size: 15, weight: .regular)
    static let bodyBold = Font.system(size: 15, weight: .bold)
    static let small = Font.system(size: 13, weight: .regular)
}
