//
//  AXColor.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 11/08/26.
//

import SwiftUI

enum AXColor {

    static let primary = Color("primary")
    static let secondary = Color("secondary")

    static let background = Color("background")
    static let surface = Color("surface")

    static let success = Color("success")
    static let warning = Color("warning")
    static let error = Color("error")

    static let textPrimary = Color("textPrimary")
    static let textSecondary = Color("textSecondary")

    static let separator = Color("separator")
}

enum AppColors {
    static let airbusBlue = Color(red: 0.01, green: 0.03, blue: 0.36)
    static let airbusActionBlue = Color(red: 0.00, green: 0.12, blue: 0.70)
    static let pageBackground = Color(red: 0.96, green: 0.97, blue: 0.98)
    static let cardBackground = Color.white
    static let border = Color(red: 0.84, green: 0.86, blue: 0.90)
    static let textPrimary = Color(red: 0.05, green: 0.07, blue: 0.18)
    static let textSecondary = Color(red: 0.35, green: 0.39, blue: 0.48)
    static let green = Color(red: 0.18, green: 0.60, blue: 0.38)
    static let gold = Color(red: 0.78, green: 0.62, blue: 0.25)
}
