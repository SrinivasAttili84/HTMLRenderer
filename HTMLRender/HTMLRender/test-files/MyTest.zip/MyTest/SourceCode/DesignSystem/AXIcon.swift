//
//  AXIcon.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 11/08/26.
//

enum AXIcon {

    static let home = "house"

    static let search = "magnifyingglass"

    static let settings = "gearshape"

    static let aircraft = "airplane"

    static let manual = "doc.text"

    static let bookmark = "bookmark"

    static let sync = "arrow.triangle.2.circlepath"

    static let menu = "line.3.horizontal"
}
