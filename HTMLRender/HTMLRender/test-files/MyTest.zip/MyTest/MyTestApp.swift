//
//  MyTestApp.swift
//  MyTest
//
//  Created by Attili Naga Srinivasu on 10/08/26.
//

import SwiftUI
//
//@main
//struct MyTestApp: App {
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//        }
//    }
//}

@main
struct AirNavXApp: App {
    @StateObject private var container = AppContainer()

    var body: some Scene {
        WindowGroup {
            NavigationStack(path: $container.router.path) {
                HomeView(viewModel: container.makeHomeViewModel())
                    .navigationDestination(for: AppRoute.self) { route in
                        switch route {
                        case .manualViewer(let manualCode):
                            Text("Viewer Screen - \(manualCode)")
                                .font(.largeTitle)
                        case .recentElementDetails(let elementId):
                            Text("Details Screen - \(elementId)")
                                .font(.largeTitle)
                        }
                    }
            }
            .environmentObject(container)
        }
    }
}
